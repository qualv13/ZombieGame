package lab13;

public interface SpriteFactory {
    Sprite newSprite(int x,int y);
}
