package lab13;

public interface CrossHairListener {
    void onShotsFired(int x,int y);
}
